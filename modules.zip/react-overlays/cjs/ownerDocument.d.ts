/// <reference types="react" />
declare const _default: (componentOrElement: Element | import("react").ComponentClass<{}, any> | null | undefined) => Document;
export default _default;
