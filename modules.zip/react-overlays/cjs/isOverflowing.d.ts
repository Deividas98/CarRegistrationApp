export default function isOverflowing(container: Element): boolean;
