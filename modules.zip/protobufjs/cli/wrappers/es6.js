import * as $protobuf from $DEPENDENCY;

$OUTPUT;

export { $root as default };
