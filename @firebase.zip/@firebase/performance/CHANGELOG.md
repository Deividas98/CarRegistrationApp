# Unreleased


# 0.3.0
- [changed] Updated internal performance event transport mechanism.

# 0.2.30
- [changed] Internal transport protocol update from proto2 to proto3.