#Unreleased
- [Changed] Added an additional header to all network requests that propagates the Firebase App ID.
 
# 6.1.0 
- [Feature] Added the support for List API.
