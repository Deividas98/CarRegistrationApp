import { Rect } from "../types";
export default function getDocumentRect(element: HTMLElement): Rect;
