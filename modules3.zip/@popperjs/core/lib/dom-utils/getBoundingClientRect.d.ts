import { ClientRectObject, VirtualElement } from "../types";
export default function getBoundingClientRect(element: Element | VirtualElement): ClientRectObject;
