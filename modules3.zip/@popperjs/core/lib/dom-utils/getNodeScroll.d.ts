import { Window } from "../types";
export default function getNodeScroll(node: Node | Window): any;
