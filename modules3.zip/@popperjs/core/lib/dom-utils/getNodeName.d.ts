import { Window } from "../types";
export default function getNodeName(element: (Node | null | undefined) | Window): string | null | undefined;
