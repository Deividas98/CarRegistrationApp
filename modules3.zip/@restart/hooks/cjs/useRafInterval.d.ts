declare function useRafInterval(fn: () => void, ms: number): void;
export default useRafInterval;
