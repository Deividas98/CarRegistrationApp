export default function offset(node: HTMLElement): {
    top: number;
    left: number;
    height: number;
    width: number;
};
