export default function qsa(element: HTMLElement | Document, selector: string): HTMLElement[];
