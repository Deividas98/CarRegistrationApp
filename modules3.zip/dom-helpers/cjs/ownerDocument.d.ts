export default function ownerDocument(node?: Element): Document;
