export default function matches(node: Element, selector: string): boolean;
