export default function getComputedStyle(node: HTMLElement, psuedoElement?: string): CSSStyleDeclaration;
