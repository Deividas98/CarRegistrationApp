export default function contains(context: Element, node: Element): boolean | undefined;
