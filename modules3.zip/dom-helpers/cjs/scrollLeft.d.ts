declare const _default: {
    (node: Element): number;
    (node: Element, val: number): undefined;
};
export default _default;
