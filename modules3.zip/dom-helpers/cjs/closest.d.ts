export default function closest(node: Element, selector: string, stopAt?: Element): Element | null;
