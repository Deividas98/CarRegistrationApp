export default function ownerWindow(node?: Element): Window;
